stopslang
=========

There is detection of slang in the any text

How it works.

String dirtyText = "...";
StopSlang  slangDetection = new StopSlang();
#for cut slang words
System.out.println(slangDetection.removeSlang(dirtyText));
#for detection slang word
System.out.println(slangDetection.detectSlang(dirtyText));