package org.stopslang.impl;

import org.stopslang.main.StopSlang;

// TODO: Auto-generated Javadoc
/**
 * The Class Main.
 */
public class Main {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String dirtyText = "охуенный Зеленный хуй Идите в пизду, у меня порш, у машины ахуенный дизайн";
		StopSlang ss = new StopSlang();
		ss.setBeep("Ой!");
		System.out.println(ss.removeSlang(dirtyText));

		
	}

}
