package org.stopslang.main;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// TODO: Auto-generated Javadoc
/**
 * The Class StopSlang.
 */
public class StopSlang {

	/** The beep. */
	private String beep = "****";
	
	/** The word. */
	private String word;	
	
	/** The properties. */
	private Properties properties;	

	/**
	 * Instantiates a new stop slang.
	 */
	public StopSlang() {
		properties = new Properties();
		try {
			properties.load(					
					new InputStreamReader(		                     
							getClass().getResourceAsStream("/org/stopslang/rules/rules.properties") , "UTF8"
		                      )
					);
			word = this.properties.getProperty("word");
			
		} catch (IOException | ArrayIndexOutOfBoundsException e) {		
			e.printStackTrace();
		} 
	}  
	
	/**
	 * Instantiates a new stop slang.
	 *
	 * @param rulesPropeties the rules properties
	 */
	public StopSlang(String rulesPropeties) {
		properties = new Properties();
		try {
			properties.load(					
					new InputStreamReader(
		                      new FileInputStream(rulesPropeties), "UTF8"
		                      )
					);
			word = this.properties.getProperty("word");
			
		} catch (IOException | ArrayIndexOutOfBoundsException e) {		
			e.printStackTrace();
		}
	}
	
	
	
/*	public void loadDictionary(String dictionary) {
		
			
	}*/
	
	
	/**
 * Sets the beep.
 *
 * @param beep the new beep
 */
	public void setBeep(String beep) {
		this.beep = beep;
	}
	
	
	/**
	 * Gets the beep.
	 *
	 * @return beep value
	 */
	public String getBeep() {
		return this.beep;
	}
	
	/**
	 * Removes the slang.
	 *
	 * @param dirtyText - text with slang
	 * @return cleanText - text without slang
	 */
	public String removeSlang(String dirtyText) {
		String pattern = "(?:\\b|(?<=_))(?:"+word+")(?:\\b|(?=_))";
		String cleanText = dirtyText.replaceAll(pattern, this.getBeep());
		return cleanText;
	}
	
	/**
	 * Detect slang.
	 *
	 * @param dirtyText the dirty text
	 * @return boolean value  - true slang is detected
	 */
	public boolean detectSlang(String dirtyText) {
		String pattern = "(?:\\b|(?<=_))(?:"+word+")(?:\\b|(?=_))";
		Pattern reqular = Pattern.compile(pattern);
		Matcher matcher = reqular.matcher(dirtyText);
		return matcher.find(); 
	}
	

}
