package org.stopslang.tests;

import static org.junit.Assert.*;

import org.junit.Test;
import org.stopslang.main.StopSlang;

// TODO: Auto-generated Javadoc
/**
 * The Class DetectionSlangTest.
 */
public class DetectionSlangTest {

	
	
	
	/**
	 * Detection slang test.
	 */
	@Test
	public void detectionSlangTest() {
		String dirtyText = "Идите нахуй со своими правилами";		
		StopSlang ss = new StopSlang();		
		assertTrue(ss.detectSlang(dirtyText));
		
	}
	
	/**
	 * Checks if is clean text test.
	 */
	@Test
	public void isCleanTextTest() {
		String cleanText = "Идите гулять со своими правилами";		
		StopSlang ss = new StopSlang();		
		assertFalse(ss.detectSlang(cleanText));
		
	}
	
	

}
