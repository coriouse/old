import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import tasktest.serverapi.users.FreindControl;



public class FreindsControlTest {

	FreindControl freinds;
	
	@Before
	public void setUp() throws Exception {
		freinds = new FreindControl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetListFreinds() throws Exception {	    
		int id = 1;
		List<tasktest.shared.User> freindsList = freinds.getListFreinds(id);
		assertEquals(3, freindsList.size());
	}

}
