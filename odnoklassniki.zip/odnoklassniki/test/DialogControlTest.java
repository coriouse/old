import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import tasktest.serverapi.users.DialogControls;
import tasktest.serverapi.users.FreindControl;
import tasktest.shared.Message;


public class DialogControlTest {
	
	private DialogControls  dialogControl;
	
	@Before
	public void setUp() throws Exception {
		dialogControl = new DialogControls();
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testGetDialogByUser() {
		int ownerId = 1;
		int dilogWithId = 2;
		//Можем конечно структурно передать array('OwnerId' => 1, 'dilogWithId' => 3 ) 
		List<Message> dialog = dialogControl.getDialogByUser(ownerId, dilogWithId);
		assertEquals(3,dialog.size());
	}

}
