import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import tasktest.client.UserItem;
import tasktest.serverapi.users.UserProfile;


public class UserProfileTest {
	private UserProfile userProfile;
 
	@Before
	public void setUp() throws Exception {
		 userProfile = new UserProfile();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetProfile() throws Exception {
		int id = 1;
		tasktest.shared.User user =  userProfile.getProfile(id);
		assertEquals("Иван",user.getFirstName());
		assertEquals("Иванов",user.getSecondName());
		assertEquals(1,user.getId());
		
		
	}

}
