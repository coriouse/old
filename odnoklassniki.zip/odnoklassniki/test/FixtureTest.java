import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import tasktest.serverapi.users.Fixture;


public class FixtureTest {
	
	private Fixture fixture;

	@Before
	public void setUp() throws Exception {
		this.fixture = new Fixture();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetFixtureDoc() {
		assertNotNull(this.fixture.getFixture());
	}

}
