import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import tasktest.serverapi.users.AuthControl;
import tasktest.shared.User;


public class AuthTest {
	private AuthControl authControl;

	@Before
	public void setUp() throws Exception {
		authControl = new AuthControl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCheckAuthOk() throws Exception {
		String login = "user1";
		//не придираемся к безопасновсти
		String password = "user123";		
		User id = this.authControl.checkAuth(login, password);		
		assertEquals(1, id.getId());		
	}
	
	@Test
	public void testCheckAuthNone() {
		String login = "user32";
		String password = "user123";		
		int count = 0;
		try {
			this.authControl.checkAuth(login, password);
		} catch(Exception e) {
			count++;
		}				 
		assertEquals(1,count);
	}

}
