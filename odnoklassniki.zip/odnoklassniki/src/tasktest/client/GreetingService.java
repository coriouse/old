package tasktest.client;

import java.util.List;

import tasktest.shared.Message;
import tasktest.shared.User;



import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

/**
 * The client side stub for the RPC service.
 */
@RemoteServiceRelativePath("greet")
public interface GreetingService extends RemoteService {
	String greetServer(String name) throws IllegalArgumentException;
	User checkAuth(String login, String password) throws Exception;	
	List<Message> getDialogByUser(int ownerId, int dilogWithId) throws Exception;
	User getProfile(int id) throws Exception;
	List<User> getListFreinds(int id) throws Exception;
}
