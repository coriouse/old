package tasktest.client;

import tasktest.shared.User;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Cookies;
import com.google.gwt.user.client.ui.RootPanel;

/**
 * @TODO архитектура канеш хреновая получилась
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class Odnoklassniki implements EntryPoint {
	
	public Odnoklassniki() {
		if(Cookies.getCookie("session") != null) {
			Cookies.removeCookie("session");
		}
	}
	

	private GreetingServiceAsync greetingService = GWT
			.create(GreetingService.class);
	
	private RootPanel rootPanel;	
	private User user;	
	
	public GreetingServiceAsync getGreetingService() {
		return greetingService;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}	
	
	
	public Integer getRegistredId() {
		return Integer.valueOf(Cookies.getCookie("session")); 
	}
	
	public RootPanel getRootPanel() {
		return rootPanel;
	}
	

	/*
	 * Метод logout
	 * @auth Огарков Сергей
	 */
	public void logout() {
		Cookies.removeCookie("session");
		getRootPanel().get("area").clear();
		this.onModuleLoad();
	}
	
	
	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		MainWidget mw = null;
		if(Cookies.getCookie("session") != null) {			
			
			try {
				mw = new MainWidget(this);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			rootPanel.get("area").add(mw);
		} else {
			LoginWidget lw = new LoginWidget(this); 		
			rootPanel.get("area").add(lw);
		}
		
	}
}
