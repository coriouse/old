package tasktest.client;

import tasktest.shared.Message;

import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Вижет для каждого сообщения необходим если надо расширить функциональность
 * @TODO
 * @auth Огарков Сергей
 */
public class MessageItemWidget extends VerticalPanel {
	public MessageItemWidget(Message messageItem) {		
		add(new Label(messageItem.getMessage()));		
	}
	
}
