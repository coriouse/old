package tasktest.client;


import tasktest.shared.User;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Hyperlink;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

/**
 * Виджит который объеденяет в себя компоненты интерфейса
 * @auth Сергей Огарков
 * В конструктор передаем Odnoklassniki
 */
public class MainWidget extends VerticalPanel{
	HeaderWidget 	headerWidget;
	InfoWidget 		infoWidget;
	Hyperlink 		myPage;
	Odnoklassniki 	odnoklassniki;
	
	public MainWidget(Odnoklassniki odnoklassniki) throws Exception {
		 this.odnoklassniki = odnoklassniki;		
		 myPage = new Hyperlink("Мой профиль","my");
		 headerWidget = new HeaderWidget( this.odnoklassniki );		 
		 infoWidget = new InfoWidget(this.odnoklassniki);		
		 add(myPage);
		 add(headerWidget);
		 add(infoWidget);
		 //Возвращаемся к профилью зераганого пользователя
		 myPage.addClickListener(new ClickListener() {
		        public void onClick(Widget sender) {
		        	try {
		        		MainWidget.this.changeProfile(MainWidget.this.odnoklassniki.getRegistredId());
					} catch (Exception e) {							
						e.printStackTrace();
					}
		        	
		        }
		    });
	}
	
	public void changeProfile(Integer id) throws Exception {            	
     	this.odnoklassniki.getGreetingService().getProfile(Integer.valueOf(id),					
					new AsyncCallback<User>() {
						public void onFailure(Throwable caught) {
							//errorLabel.setText("serverResponseLabelError");							
						}
						public void onSuccess(User result) {							
							updateProfile(result);	
						}
					});
     	
     	
     }
	
	public void updateProfile(User user) {
		MainWidget.this.odnoklassniki.setUser(user);
		MainWidget.this.odnoklassniki.getRootPanel().get("area").clear();
		MainWidget.this.odnoklassniki.onModuleLoad();		
	}
	
}
