package tasktest.client;

import tasktest.shared.FieldVerifier;
import tasktest.shared.User;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Cookies;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * @TODO
 * Виджит авторизации Сделал сильну связь между root панелью и виджитом что не правильно 
 * @auth Огарков Сергей
 *   
 */
public class LoginWidget extends VerticalPanel {
	
	
	PasswordTextBox password = new PasswordTextBox();
    TextBox login = new TextBox();
    Button enterButton = new Button("Вход");
    Label errorLabel = new Label("");
    Odnoklassniki odnoklassniki;
    
    public LoginWidget(Odnoklassniki odnoklassniki) {
    	this.odnoklassniki = odnoklassniki;
    	add(login);
    	add(password);    	
    	add(enterButton);   
    	add(errorLabel);
    	AuthHandler handler = new AuthHandler();
        enterButton.addClickHandler(handler);
    }
    
         /**
          * Обработка клика и объен данными с сервером
          * 
          */
 	  	class AuthHandler implements ClickHandler { 			
 			public void onClick(ClickEvent event) {
 				try {
					sendAuth();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
 			} 			
 			/**
 			 * Send the name from the nameField to the server and wait for a response.
 			 * @throws Exception 
 			 */
 			private void sendAuth() throws Exception {
 				errorLabel.setText("");
 				String loginFiled = login.getText();
 				String passwordFiled = password.getText();
 				if (!(loginFiled.length() > 0) || !FieldVerifier.isEmpty(passwordFiled)) {
 					errorLabel.setText("Поле логин и пароль не может быть пустым");
 					return;
 				}
 				
 				getGreetingService().checkAuth(loginFiled, passwordFiled,
 						new AsyncCallback<User>() {
 							public void onFailure(Throwable caught) {
 								// Show the RPC error message to the user
 								errorLabel.setText("serverResponseLabelError");
 								errorLabel.getText();
 							}
 							public void onSuccess(User result) { 	
 								//сессия для теста 								
 								Cookies.setCookie("session",String.valueOf(result.getId()));
 								setUser(result);
 								hide();
 							}
 						});
 			}
 		}
 	 /**
 	  * @auth Огарков Сергей
 	  * Убираем панель авторизации 	
 	  */
    public void hide() {
    	odnoklassniki.getRootPanel().get("area").clear();    	
    	odnoklassniki.onModuleLoad();
    }
    
    public void setUser(User user) {
    	odnoklassniki.setUser(user);
    }
    public GreetingServiceAsync getGreetingService() {
    	return odnoklassniki.getGreetingService();
    }    
 	
	

}
