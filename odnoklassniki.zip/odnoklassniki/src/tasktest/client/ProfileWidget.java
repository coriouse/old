package tasktest.client;



import tasktest.shared.User;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * @auth Огарков Сергей
 * Вджет формирует провиль пользователя
 * Передаем  в конструктор Odnoklassniki
 */
public class ProfileWidget extends VerticalPanel {
	Label id 			= new Label("");
	Label firstName 	= new Label("");
	Label secondName 	= new Label("");
	Label errorLabel 	= new Label("");	
	Odnoklassniki odnoklassniki;
	public ProfileWidget(Odnoklassniki odnoklassniki) throws Exception {
		this.odnoklassniki = odnoklassniki;
		add(id);
		add(firstName);
		add(secondName);
		add(errorLabel);
		//получаем пользователя по умолчанию с загрузкой виджета
		this.getProfile();
	}
	/**
	 * @auth Огарков Сергей
	 * Метод получает профиль пользователя класс User
	 * 
	 */
	private void getProfile() throws Exception {
		getGreetingService().getProfile(odnoklassniki.getUser().getId(),
					new AsyncCallback<User>() {
						public void onFailure(Throwable caught) {
							errorLabel.setText("serverResponseLabelError");							
						}
						public void onSuccess(User result) { 	 								
							id.setText(String.valueOf(result.getId()));
							firstName.setText(result.getFirstName());
							secondName.setText(result.getSecondName());
							ProfileWidget.this.setUser(result);
						}
					});
		
	}
	 
	public GreetingServiceAsync getGreetingService() {
    	return odnoklassniki.getGreetingService();
    }  
	/**
	 * @auth Огарков Сергей
	 * @params устанавливаем нового пользователя
	 * 
	 */
	public  void setUser(User user) {
		odnoklassniki.setUser(user);
	}
	
	
	
}
