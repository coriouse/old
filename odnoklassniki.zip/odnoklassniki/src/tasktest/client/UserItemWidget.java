package tasktest.client;

import java.util.List;

import tasktest.shared.Message;
import tasktest.shared.User;

import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.MouseOutEvent;
import com.google.gwt.event.dom.client.MouseOutHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.user.client.History;
import com.google.gwt.user.client.HistoryListener;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Hyperlink;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.MouseListener;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

/**
 * @auth Огарков Сергей
 * Класс которые формируем пользователя сюда можно добавлять разные свойства если понадобится
 * Передаем  в конструктор id пользователя и UserListWidget 
 */
public class UserItemWidget extends HorizontalPanel {
	UserListWidget userListWidget;
    int userId;
    
    /**
     * @auth Огарков Сергей
     * Диалоговое окно (Шотак меню)
     * Передаем  в конструктор User , UserListWidget // мдяя
     */
	private static class PopUpMenu extends DialogBox  {
		 Hyperlink dialoglLink;
		 Hyperlink profileLink;
		 Hyperlink hideDialogLink;
		 UserListWidget userListWidget;
		 VerticalPanel messageList;
		    public PopUpMenu(String id, UserListWidget userListWidget) throws Exception{		    	
		    	 messageList 			= new VerticalPanel();
		    	 this.userListWidget	= userListWidget;
		    	 dialoglLink	  		= new Hyperlink("Диалог", id);
		    	 profileLink 			= new Hyperlink("Профиль", id);		    	 
		    	 hideDialogLink 		= new Hyperlink("Закрыть диалог", "");
		    	 
		    	 //события 				    	 
		    	 dialoglLink.addClickListener(new ClickListener() {
	 			        public void onClick(Widget sender) {
	 			        	try {
	 			        		PopUpMenu.this.updateDialogList();
	 			        		
							} catch (Exception e) {							
								e.printStackTrace();
							}
	 			        		PopUpMenu.this.hide();
	 			        }
	 			    });
		    	 
		    	 
		    	 profileLink.addClickListener(new ClickListener() {
	 			        public void onClick(Widget sender) {
	 			        	try {
								PopUpMenu.this.changeProfile(profileLink.getTargetHistoryToken());
							} catch (Exception e) {							
								e.printStackTrace();
							}
	 			        	PopUpMenu.this.hide();
	 			        }
	 			    }); 
		    	 
		    	 hideDialogLink.addClickListener(new ClickListener() {
	 			        public void onClick(Widget sender) {
	 			        	PopUpMenu.this.hide();
	 			        }
	 			    }); 
		    	 
		    	 //@TODO жесткач конечно
		    	 setPopupPosition( 600, 270 );
		    	 VerticalPanel listVertical = new VerticalPanel();
		    	 if(userListWidget.infoWidget.odnoklassniki.getRegistredId() == userListWidget.infoWidget.odnoklassniki.getUser().getId()) {
		    		 listVertical.add(dialoglLink);
		    	 }
		    	 	listVertical.add(profileLink);
		    	 	listVertical.add(hideDialogLink);
		    	 	setWidget(listVertical);
		    	 	hide(); 
		    }
		    /**
             * @auth Огарков Сергей
             * Обновление списка диалогов
             * 
             */
		    public void updateDialogList() throws NumberFormatException, Exception {
		    		PopUpMenu.this.userListWidget.infoWidget.dialogList.messageList.clear();
	        		PopUpMenu.this.userListWidget.infoWidget.dialogList.messageList.add(this.getListMessage(this.dialoglLink.getTargetHistoryToken()));	 			        		
	        		PopUpMenu.this.userListWidget.infoWidget.selectTab(1, true);
	        		PopUpMenu.this.userListWidget.infoWidget.dialogList.statusDialog.setText("");
	        		PopUpMenu.this.userListWidget.infoWidget.dialogList.sendMessage.setEnabled(true);
		    }
		    
		    
            public void onMouseLeave(Widget sender) {
            	 hide();
            }
            /**
             * @auth Огарков Сергей
             * Формируем список сообщений
             * @params id  друга
             * @return  VerticalPanel список сообщение
             * 
             */
            public VerticalPanel getListMessage(String id) throws NumberFormatException, Exception {
            	 
            	PopUpMenu.this.userListWidget.getGreetingService().getDialogByUser(PopUpMenu.this.userListWidget.infoWidget.odnoklassniki.getRegistredId(), Integer.valueOf(id),					
    					new AsyncCallback<List<Message>>() {
    						public void onFailure(Throwable caught) {
    							//errorLabel.setText("serverResponseLabelError");							
    						}
    						public void onSuccess(List<Message> result) {
    							hide();    							
    							for(Message message : result) {
    								PopUpMenu.this.messageList.add(new MessageItemWidget(message));
    							}
    						}
    					});
            	
            	return this.messageList;
            }
            	
            
            /**
             * @auth Огарков Сергей
             * Загружаем профиль пользователя
             * @params id пользователя              
             * 
             */
            public void changeProfile(String id) throws Exception {            	
            	PopUpMenu.this.userListWidget.getGreetingService().getProfile(Integer.valueOf(id),					
    					new AsyncCallback<User>() {
    						public void onFailure(Throwable caught) {
    							//errorLabel.setText("serverResponseLabelError");							
    						}
    						public void onSuccess(User result) {
    							hide();
    							PopUpMenu.this.userListWidget.infoWidget.odnoklassniki.setUser(result);
    							userListWidget.infoWidget.odnoklassniki.getRootPanel().get("area").clear();
    							PopUpMenu.this.userListWidget.infoWidget.odnoklassniki.onModuleLoad();
    						}
    					});
            }
	 }
	
	
	public UserItemWidget(User userItem, UserListWidget userListWidget) {
		    userId 				= userItem.getId();
		 	this.userListWidget = userListWidget;
		 	String userItemLink = String.valueOf(userId)+". "+userItem.getFirstName()+" "+userItem.getSecondName();
		 	Hyperlink dialogPopUp = new Hyperlink(userItemLink, String.valueOf(userId));		 	
		 	dialogPopUp.addClickListener(new ClickListener() {
		 			        public void onClick(Widget sender) {
		 			        	try {
									new PopUpMenu(String.valueOf(userId), UserItemWidget.this.userListWidget).show();
								} catch (Exception e) {								
									e.printStackTrace();
								}
		 			        }
		 			    });
			add(dialogPopUp);			
	 }
}
