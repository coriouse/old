package tasktest.client;

import java.util.List;

import tasktest.shared.Message;
import tasktest.shared.User;



import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * The async counterpart of <code>GreetingService</code>.
 */
public interface GreetingServiceAsync {
	void greetServer(String input, AsyncCallback<String> callback)
			throws IllegalArgumentException;
	
	void checkAuth(String login, String password,AsyncCallback<User> callback)
			throws Exception;
	
	void getDialogByUser(int ownerId, int dilogWithId, AsyncCallback<List<Message>> callback) throws Exception;
	void getProfile(int id,  AsyncCallback<User> callback) throws Exception;
	void getListFreinds(int id,  AsyncCallback<List<User>> asyncCallback) throws Exception;
	
	
}
