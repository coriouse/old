package tasktest.client;

import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;


/**
 * Виджит который отражает шапку(заголовок, logout)
 * @auth Сергей Огарков
 * В конструктор передаем Odnoklassniki
 */
public class HeaderWidget extends HorizontalPanel {
	AuthControlWidget acw;
	Label name = new Label("");
	Odnoklassniki odnoklassniki;
	public HeaderWidget(Odnoklassniki odnoklassniki) {
		this.odnoklassniki = odnoklassniki;		
		name.setText(this.odnoklassniki.getUser().getFirstName()+" - ");
		acw = new AuthControlWidget(this.odnoklassniki);
		add(name);
		add(acw);
	}

	
	
	
}
