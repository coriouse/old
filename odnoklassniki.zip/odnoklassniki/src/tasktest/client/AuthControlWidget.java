package tasktest.client;


import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Hyperlink;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;


/**
 * Виджит  формирует панель logout
 * @auth Сергей Огарков
 * В конструктор передаем Odnoklassniki
 */
public class AuthControlWidget extends HorizontalPanel{	
	Label login = new Label("");
	Hyperlink logoutLink; 
	Odnoklassniki odnoklassniki;
	
	public AuthControlWidget(Odnoklassniki odnoklassniki) {
		this.odnoklassniki 	= odnoklassniki;		
		logoutLink 			= new Hyperlink("Выход","logout");		
		logoutLink.addClickListener(new ClickListener() {
		        public void onClick(final Widget sender) {
				        	logout();
		        }
		    });
		add(login);
		add(logoutLink);	
	}
	
	
	public void logout() {
    	odnoklassniki.logout();
	}
	
}
