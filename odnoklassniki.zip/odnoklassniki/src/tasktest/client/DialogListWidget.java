package tasktest.client;

import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Виджит  формирует панель диалога
 * @auth Сергей Огарков
 * В конструктор передаем Odnoklassniki
 */
public class DialogListWidget extends VerticalPanel {	
	Odnoklassniki odnoklassniki;
	TextArea messageText  		= new TextArea();
	Button sendMessage 			= new Button("Отправить");
	VerticalPanel messageList 	= new VerticalPanel(); 
	Label statusDialog 			= new Label("");
	
	public DialogListWidget(Odnoklassniki odnoklassniki) {		
		this.odnoklassniki	 		= odnoklassniki;
		HorizontalPanel addMessage 	= new HorizontalPanel();
		messageText.setCharacterWidth(80);
		messageText.setVisibleLines(10);
		statusDialog.setText("Диалог не выбран");
		sendMessage.setEnabled(false);
		add(statusDialog);			
		add(messageList);
		addMessage.add(messageText);
		addMessage.add(sendMessage);		
		add(addMessage);
	}	
}
