package tasktest.client;



import java.util.List;

import tasktest.shared.User;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * @auth Огарков Сергей
 * Класс которые формируем список пользователей
 * Передаем  в конструктор InfoWidget 
 */
public class UserListWidget extends VerticalPanel {
	InfoWidget infoWidget;
	Label errorLabel 	= new Label("");
	public UserListWidget(InfoWidget infoWidget) throws Exception {
		this.infoWidget = infoWidget;
		this.getListUsers();
	}
	/**
     * @auth Огарков Сергей
     * Выводим список друзей пользователя
     * 
     */
	private void getListUsers() throws Exception {
		getGreetingService().getListFreinds(this.infoWidget.odnoklassniki.getUser().getId(),					
					new AsyncCallback<List<User>>() {
						public void onFailure(Throwable caught) {
							errorLabel.setText("serverResponseLabelError");							
						}
						public void onSuccess(List<User> result) {							
							for(User user : result) {								
								add(new UserItemWidget(user, UserListWidget.this));								
							}
							
						}
					});
		
	}
	public GreetingServiceAsync getGreetingService() {
    	return this.infoWidget.odnoklassniki.getGreetingService();
    }	

}
