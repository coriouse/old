package tasktest.client;

import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TabBar;
import com.google.gwt.user.client.ui.TabPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Виджит который отражает данные о пользователе (Список друзей, Диалоги(если это владелец аккаунта), Профиль пользователя)
 * @auth Сергей Огарков
 */
public class InfoWidget extends TabPanel {
	UserListWidget userList;
	DialogListWidget dialogList; 
	ProfileWidget profile;
	Odnoklassniki odnoklassniki;
	int selectTab;
	public InfoWidget(Odnoklassniki odnoklassniki) throws Exception {
		this.odnoklassniki  = odnoklassniki;		
		userList 			= new UserListWidget(this); 
		dialogList 			= new DialogListWidget(this.odnoklassniki);
		profile 			= new ProfileWidget(this.odnoklassniki);
		
		add(userList,"Список друзей");
		//Проверяем на зарегистрированого пользователя
		if(this.odnoklassniki.getRegistredId() == this.odnoklassniki.getUser().getId()) {
			add(dialogList,"Моя переписка");
			selectTab = 2;
		} else {			
			selectTab = 1;
		}	
		add(profile,"Профиль пользователя");		
		selectTab(selectTab);
	}
}
