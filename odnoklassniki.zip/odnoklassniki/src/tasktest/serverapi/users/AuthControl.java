package tasktest.serverapi.users;

import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.dom4j.XPath;

import tasktest.shared.User;

public class AuthControl extends Fixture {
	
	public AuthControl() throws DocumentException {
		super();
	}

	public User checkAuth(String login, String password) throws Exception {
		Node node = this.getFixture().selectSingleNode("/users/user[@login='"+login+"']");
		String idUser = node.valueOf( "@id" );
		if(!(idUser.length() > 0)) throw new Exception("Пользователь не найден");
		String firstName = node.valueOf( "@firstName" );
		String secondName = node.valueOf( "@secondName" );
		User user = new User();
		user.setFirstName(firstName);
		user.setSecondName(secondName);
		user.setId(Integer.valueOf(idUser));
		return user;
	}
	
	public void logOut() {
		//если сессию хранить на сервере
	}
	

}
