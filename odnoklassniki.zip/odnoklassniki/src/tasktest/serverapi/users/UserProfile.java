package tasktest.serverapi.users;

import org.dom4j.DocumentException;
import org.dom4j.Node;
import tasktest.shared.User;

public class UserProfile  extends Fixture {
	
	public UserProfile() throws DocumentException {
		super();
	}
	
		
	public User getProfile(int id) throws Exception {		
		Node node = this.getFixture().selectSingleNode("/users/user[@id='"+id+"']");		
		String firstName = node.valueOf( "@firstName" );
		String secondName = node.valueOf( "@secondName" );
		String idUser = node.valueOf( "@id" );
		
		if(!(firstName.length() > 0)) 
			throw new Exception("Пользователь не найден");
		User user = new User();
		user.setFirstName(firstName);
		user.setSecondName(secondName);
		user.setId(Integer.valueOf(idUser));
		return user;
	}
	

}
