package tasktest.serverapi.users;

import java.util.ArrayList;
import java.util.List;

import org.dom4j.DocumentException;
import org.dom4j.Node;

import tasktest.shared.Message;

public class DialogControls extends Fixture  {
	public DialogControls() throws DocumentException {
		super();		
	}

	public void addMessageToDialog(Message message) {
		//Добавляем
	}
	
	public void removeMessageFromDialog(Message message) {
		//Удаляем
	}
	
	
	public List<Message> getDialogByUser(int ownerId, int dilogWithId) {
		List listMessages = new ArrayList<Message>();
		//@TODO
		List<Node> nodes = (List<Node>) this.getFixture().selectNodes("/users/user[@id='"+ownerId+"']/freinds/freind[@id='"+dilogWithId+"']/dialog/message");
		for(Node node : nodes) {
			String message = node.getStringValue();
			//конечно можно через конструктор передавать
			Message objMeaage = new Message();
			objMeaage.setMessage(message);
			objMeaage.setDialogWithId(dilogWithId);
			objMeaage.setUserOwner(ownerId);
			listMessages.add(objMeaage);
		}
		return listMessages;
	}

}
