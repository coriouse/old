package tasktest.serverapi.users;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;

public class Fixture {	
	private Document document;	
	public Fixture() throws DocumentException {
		//будем считать, что файл внешний использует property и настроен как надо через WEB-INF
		this.parseWithSAX("/home/user/workspace1/odnoklassniki/war/fixture.xml");
		
	}
	
	private void parseWithSAX(String aFile) throws DocumentException {
	    SAXReader xmlReader = new SAXReader();
	    this.document = xmlReader.read(aFile);
	 }
	
	public Document getFixture() {
		return this.document;
	}

}
