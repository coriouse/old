package tasktest.serverapi.users;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;

import tasktest.shared.User;

/*
 * Пустой класс по управление друзьями 
 * @auth Огарков Сергей
 */
public class FreindControl extends Fixture {
	
	public FreindControl() throws DocumentException {
		super();		
	}

	public void addFreind(User user) {
		//TODO
	}
	
	public void removeFreind(User user) {
		//TODO
	}
	
	/*
	 * Получить список пользователей
	 * @auth Огарков Сергей
	 * 
	 */
	public List<User> getListFreinds(int id) throws Exception {
		List<User> listUsers = new ArrayList();
		//@TODO
		List<Node> nodes = (List<Node>) this.getFixture().selectNodes("/users/user[@id='"+id+"']/freinds/freind");
		for(Node node : nodes) {
			String idUser = node.valueOf( "@id" );
			listUsers.add(this.getUserById(Integer.valueOf(idUser)));
		}
		return listUsers;

	}	
	
    /*
     * Получить объект User по id пользователя метод похож на getProfile
     * @auth Огарков Сергей
     */
	private User getUserById(int id) throws Exception {
		Node node = this.getFixture().selectSingleNode("/users/user[@id='"+id+"']");
		String firstName = node.valueOf( "@firstName" );
		String secondName = node.valueOf( "@secondName" );
		String idUser = node.valueOf( "@id" );		
		if(!(firstName.length() > 0)) 
			throw new Exception("Пользователь не найден");
		User user = new User();
		user.setFirstName(firstName);
		user.setSecondName(secondName);
		user.setId(Integer.valueOf(idUser));
		return user;
	}
	
	
}
