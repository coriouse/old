package tasktest.server;

import java.util.ArrayList;
import java.util.List;

import org.dom4j.DocumentException;

import tasktest.client.GreetingService;
import tasktest.serverapi.users.AuthControl;
import tasktest.serverapi.users.DialogControls;
import tasktest.serverapi.users.FreindControl;
import tasktest.serverapi.users.UserProfile;
import tasktest.shared.FieldVerifier;
import tasktest.shared.Message;
import tasktest.shared.User;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

/**
 * The server side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class GreetingServiceImpl extends RemoteServiceServlet implements
		GreetingService {
    private AuthControl authControl;
    private DialogControls  dialogControls;
    private FreindControl freindControl;
    private UserProfile  userProfile;
    
	public GreetingServiceImpl() {
		super();
		try {
			authControl = new AuthControl();
			dialogControls = new DialogControls(); 
			freindControl = new FreindControl();
			userProfile = new UserProfile();			
			
		} catch (DocumentException e) {			
			e.printStackTrace();
		}
	}
	
	public User checkAuth(String login, String password) throws Exception, IllegalArgumentException {
		if (!FieldVerifier.isEmpty(login) || !FieldVerifier.isEmpty(login)) {
			throw new IllegalArgumentException(
					"Поля Логин или Пароль немогут быть пустыми" 
					);
		}
		return authControl.checkAuth(login, password);
	}
	
	public List<Message> getDialogByUser(int ownerId, int dilogWithId) throws Exception {
		return dialogControls.getDialogByUser(ownerId, dilogWithId);
	}
	
	 
	public User getProfile(int idUser) throws Exception {		
		return userProfile.getProfile(idUser);		
	}
	
	
	public List<User> getListFreinds(int idUser) throws Exception {
		return  freindControl.getListFreinds(idUser);
	}
	
	
	
	
	public String greetServer(String input) throws IllegalArgumentException {
		// Verify that the input is valid. 
		if (!FieldVerifier.isValidName(input)) {
			// If the input is not valid, throw an IllegalArgumentException back to
			// the client.
			throw new IllegalArgumentException(
					"Name must be at least 4 characters long");
		}
		String serverInfo = getServletContext().getServerInfo();
		String userAgent = getThreadLocalRequest().getHeader("User-Agent");

		// Escape data from the client to avoid cross-site script vulnerabilities.
		input = escapeHtml(input);
		userAgent = escapeHtml(userAgent);

		return "Hello, " + input + "!<br><br>I am running " + serverInfo
				+ ".<br><br>It looks like you are using:<br>" + userAgent;
	}

	/**
	 * Escape an html string. Escaping data received from the client helps to
	 * prevent cross-site script vulnerabilities.
	 * 
	 * @param html the html string to escape
	 * @return the escaped string
	 */
	private String escapeHtml(String html) {
		if (html == null) {
			return null;
		}
		return html.replaceAll("&", "&amp;").replaceAll("<", "&lt;")
				.replaceAll(">", "&gt;");
	}
}
