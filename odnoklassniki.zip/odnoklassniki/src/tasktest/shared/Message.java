package tasktest.shared;

import com.google.gwt.user.client.rpc.IsSerializable;

public class Message implements IsSerializable{
	private String message;
	private Integer userOwner;
	private Integer dialogWithId;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Integer getUserOwner() {
		return userOwner;
	}
	public void setUserOwner(Integer userOwner) {
		this.userOwner = userOwner;
	}
	public Integer getDialogWithId() {
		return dialogWithId;
	}
	public void setDialogWithId(Integer dialogWithId) {
		this.dialogWithId = dialogWithId;
	}
	
	

}
