package org.robot.parts;

public class Robot {
	
	String nameFoot;

	public String getNameFoot() {
		return nameFoot;
	}

	public void setNameFoot(String nameFoot) {
		this.nameFoot = nameFoot;
	}

	int step = 1;

	public int getStep() {
		return step;
	}

	public void setStep() {
		this.step++;	
				
	}
	
	
	
		
	

}
