package org.robot.parts;

import org.robot.main.Main;

public class Foot implements Runnable {
	
	//monitor
	private static final Object monitor = new Object();
	
	private Robot robot;
	
	public Foot(Robot robot) {
		this.robot = robot;
	}
	
	String step;
	
	public void setStep(String step) {
		this.step = step;
	}
	
	@Override
	public void run() {
		while(robot.getStep() < Main.STEP_COUNT) {
			  synchronized (monitor) {
				  monitor.notifyAll();
 				  System.out.println(Thread.currentThread().getName()+" "+this.step +" "+robot.getStep()); 
 				 try {
						monitor.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					} 				  
			   } 
			  robot.setStep();			 
		}
	}
}
