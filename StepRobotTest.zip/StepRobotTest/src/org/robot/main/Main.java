package org.robot.main;

import org.robot.parts.Foot;
import org.robot.parts.Robot;


public class Main {
	
	//step count
	public final static Integer STEP_COUNT = 11;
	
	public static void main(String[] args) throws InterruptedException {
	
		//Robot
		Robot robot = new Robot();
		
		//left  foot
		Foot rl =  new Foot(robot);
		rl.setStep("LEFT");
		Thread left = new Thread(rl);
		//right foot
		Foot rr =  new Foot(robot);
		rr.setStep("RIGHT");
		Thread right = new Thread(rr);
		
		//go go go
		right.start();
		left.start();
	}

}
