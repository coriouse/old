XML Transformer
=====================
Need to create the xml-transformer (don't use XSLT) of contact books. From one format to another format.<br>
Example :<br>
We have contact book <br>
&lt;book&gt;<br>
&nbsp;&nbsp;&lt;contact&gt;<br>
     &nbsp;&nbsp;&nbsp;&nbsp;&lt;id&gt;1&lt;id&gt;<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&lt;name&gt;Jon&lt;/name&gt;<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&lt;tel&gt;+75432435&lt;tel&gt;<br>
&nbsp;&nbsp;&lt;/contact&gt;<br>
&nbsp;&nbsp;&lt;contact&gt;<br>
     &nbsp;&nbsp;&nbsp;&nbsp;&lt;id&gt;2&lt;/id&gt;<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&lt;name&gt;Jenny&lt;/name&gt;<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&lt;tel&gt;+7544444&lt;tel&gt; <br>
&nbsp;&nbsp;&lt;/contact&gt;<br>
&lt;book&gt;<br>

We want to get the follow format book.<br>

&lt;contacts&gt;<br>
&nbsp;&nbsp;&lt;person id=1&gt;<br>
         &nbsp;&nbsp;&nbsp;&nbsp;&lt;contact&gt;Jon&lt;/contact&gt;<br>
         &nbsp;&nbsp;&nbsp;&nbsp;&lt;mobile&gt;+75432435&lt;/mobile&gt;<br>
&nbsp;&nbsp;&lt;/person&gt;<br>
&nbsp;&nbsp;&lt;person id=2&gt;<br>
         &nbsp;&nbsp;&nbsp;&nbsp;&lt;contact&gt;Jenny&lt;/contact&gt;<br>
         &nbsp;&nbsp;&nbsp;&nbsp;&lt;mobile&gt;+7544444&lt;/mobile&gt;<br>
&nbsp;&nbsp;&lt;/person&gt;<br>
&lt;/contacts&gt;<br>

Customer want to see any format of book in pattern files like this:<br>

<i>from.xml</i><br>

&lt;contact&gt;<br>
     &nbsp;&nbsp;&nbsp;&nbsp;&lt;id&gt;#ID&lt;/id&gt;<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&lt;name&gt;#NAME&lt;/name&gt;<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&lt;tel&gt;#TEL&lt;tel&gt;<br>
&lt;/contact&gt;<br>

<i>to.xml</i><br>
&lt;person id=#ID&gt;<br>
         &nbsp;&nbsp;&nbsp;&nbsp;&lt;contact&gt;#NAME&lt;/contact&gt;<br>
         &nbsp;&nbsp;&nbsp;&nbsp;&lt;mobile&gt;#TEL&lt;/mobile&gt;<br>
&lt;/person&gt;




