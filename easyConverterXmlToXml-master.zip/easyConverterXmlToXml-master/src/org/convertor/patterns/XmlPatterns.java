package org.convertor.patterns;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.convertor.config.Configuration;

// TODO: Auto-generated Javadoc
/**
 * The Class XmlPatterns.
 */
public class XmlPatterns {
	
	/** The configuration. */
	private Configuration configuration;
	
	/** The logger. */
	Logger logger = Logger.getLogger(this.getClass().getName());
	
	/**
	 * Instantiates a new xml patterns.
	 *
	 * @param configuration the configuration
	 */
	public XmlPatterns(Configuration configuration) {
		if(configuration == null) {
			logger.info("Error: Configuration is not loading!");
			System.exit(1);
		}
		this.configuration = configuration;
	}

	/**
	 * Gets the configuration.
	 *
	 * @return the configuration
	 */
	public Configuration getConfiguration() {
		return this.configuration;
	}
	
	/**
	 * Gets the pattern type.
	 *
	 * @param typePatterns the type patterns
	 * @return the pattern type
	 */
	private Patterns getPatternType(String typePatterns) {
		if(!"source".equals(typePatterns) || "destination".equals(typePatterns) || typePatterns.length() == 0) {
			logger.info("Error: Type pattern is not define!");
			System.exit(1);
		}   
		return typePatterns.equals("source") ? new SourcePattern() : new DestinationPattern();
	}
	
		
	/**
	 * Gets the pattern.
	 *
	 * @param type the type
	 * @return the pattern
	 */
	public HashMap<String, String> getPattern(String type) {
		Patterns pattern = getPatternType(type);
		pattern.load(this.configuration.getPattern("pattern."+type));
		return pattern.getPattern();
	}
	
	

}
