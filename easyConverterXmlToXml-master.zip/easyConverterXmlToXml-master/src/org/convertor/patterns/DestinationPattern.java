/*
 * 
 */
package org.convertor.patterns;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.convertor.main.LoadXml;

// TODO: Auto-generated Javadoc
/**
 * The Class DestinationPattern.
 */
public class DestinationPattern extends LoadXml implements Patterns {

	/** The content. */
	private String content;
	
	/** The logger. */
	Logger logger = Logger.getLogger(this.getClass().getName());

	/* (non-Javadoc)
	 * @see org.convertor.patterns.Patterns#getPattern()
	 */
	@Override
	public HashMap<String, String> getPattern() {
		this.patternList.put("destinationPattern", this.content);
		return this.patternList;
	}

	/* (non-Javadoc)
	 * @see org.convertor.patterns.Patterns#load(java.lang.String)
	 */
	@Override
	public void load(String path) {
		int ch;
		StringBuffer strContent = new StringBuffer("");
		FileInputStream filePattern = null;		    
		    try {
		    	filePattern = new FileInputStream(path);
		    	while( (ch = filePattern.read()) != -1)
		    		strContent.append((char)ch);     
		    	filePattern.close();
		    } catch(IOException e)   {
		    	logger.info("ErrorProblem with xml file", e);
				System.exit(1);
		    }
		    this.content = strContent.toString();
	}

	

}
