package org.convertor.patterns;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.convertor.main.LoadXml;
import org.dom4j.DocumentException;
import org.dom4j.Element;

// TODO: Auto-generated Javadoc
/**
 * The Class SourcePattern.
 */
public class SourcePattern extends LoadXml implements Patterns {
	
	/** The logger. */
	Logger logger = Logger.getLogger(this.getClass().getName());
	
	/* (non-Javadoc)
	 * @see org.convertor.patterns.Patterns#getPattern()
	 */
	@Override
	public HashMap<String, String> getPattern() {
		Element  root = this.doc.getRootElement();
		Iterator elementIterator = root.elementIterator();
		while(elementIterator.hasNext()){
			Element element = (Element)elementIterator.next();				
			patternList.put(element.getName(), element.getStringValue().toString());
		}		
		return patternList;
	}

	/* (non-Javadoc)
	 * @see org.convertor.patterns.Patterns#load(java.lang.String)
	 */
	@Override
	public void load(String path) {
		try {
			this.loadFile(new File(path));
		} catch (DocumentException e) {
			logger.info("ErrorProblem with xml file", e);
			System.exit(1);
		}
	}



}
