package org.convertor.patterns;

import java.util.HashMap;

// TODO: Auto-generated Javadoc
/**
 * The Interface Patterns.
 */
public interface Patterns {
	
	/**
	 * Load.
	 *
	 * @param path the path
	 */
	public void load(String path);
	
	/**
	 * Gets the pattern.
	 *
	 * @return the pattern
	 */
	public HashMap<String, String> getPattern();
}
