package org.convertor.main;

import org.convertor.config.Configuration;
import org.convertor.patterns.XmlPatterns;





// TODO: Auto-generated Javadoc
/**
 * The Class Main.
 */
public class Main {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		if(args.length < 7) {
			systemError();
		} 		
		
		if("-c".equals(args[1]) && "-s".equals(args[3]) && "-d".equals(args[5])) {
			//default
			String contentFile = "c:\\ElarYellowPages\\backup.xml";		
			String outputFile = "c:\\xml\\output\\output.xml";
			String workSpace = "c:\\xml";			
			if(args[2].length() == 0 ) {
				systemError();
			}			
			workSpace = args[2];			
			if(args[4].length() == 0 ) {
				systemError();
			}						
			contentFile = args[4];			
			if(args[6].length() == 0 ) {
				systemError();
			}			
			outputFile = args[6];
			Configuration configuration = new Configuration();				
					configuration.setPath(workSpace);
			XmlPatterns xmlPaterns = new XmlPatterns(configuration);
			Convertor convertor = new Convertor();
					convertor.setPatterns(xmlPaterns);
					convertor.setXmlFromFile(contentFile);
					convertor.setXmlToFile(outputFile);				
					convertor.convert();
		} else {
			systemError();
		}
	}
	
	private static void systemError() {
		System.err.println("java -jar -c <path> -s <file> -d <file>");
		System.exit(1);
	}
	
}
