/*
 * 
 */
package org.convertor.main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.convertor.patterns.XmlPatterns;
import org.dom4j.DocumentException;
import org.dom4j.Element;


// TODO: Auto-generated Javadoc
/**
 * The Class Convertor.
 */
public class Convertor extends LoadXml {
	
	/** The content. */
	private String content;
	
	/** The output. */
	private String output;	
	
	/** The xml paterns. */
	private XmlPatterns xmlPaterns;
	
	/** The from list. */
	private List<HashMap<String,String>> fromList;
	
	/** The destination pattern. */
	private String destinationPattern;
	
	/** The logger. */
	Logger logger = Logger.getLogger(this.getClass().getName());
	
	/**
	 * Instantiates a new convertor.
	 */
	public Convertor() {
		this.fromList = new ArrayList<HashMap<String,String>>();
	}
	
	/**
	 * Sets the xml from file.
	 *
	 * @param content the new xml from file
	 */
	public void setXmlFromFile(String content) {
		if(content.length() == 0) {
			logger.info("Error: Content Source file is not found");
			System.exit(1);
		}
		
		this.content = content;
		logger.info("Load source file..."+content);
	}
	
	/**
	 * Sets the xml to file.
	 *
	 * @param output the new xml to file
	 */
	public void setXmlToFile(String output) {
		if(output.length() == 0) {
			logger.info("Error: Path for output file is not found");
			System.exit(1);
		}
		this.output = output;
		logger.info("Set destination file path..."+output);
	}
	
	/**
	 * Sets the patterns.
	 *
	 * @param xmlPatterns the new patterns
	 */
	public void setPatterns(XmlPatterns xmlPatterns) {
		if(xmlPaterns == null) {
			logger.info("Error: Patternt is not load");
			System.exit(1);
		}
		this.xmlPaterns = xmlPatterns; 
		this.patternList = this.xmlPaterns.getPattern("source");
		this.destinationPattern = this.xmlPaterns.getPattern("destination").get("destinationPattern");
		logger.info("Load xmlPatterns...loading");
	}
		
	
	/**
	 * Convert.
	 */
	public void convert() {
		StringBuffer sb = new StringBuffer();
		sb.append("<documents>");
		for(HashMap<String, String> h: this.getFromList()) {
			String d = this.destinationPattern;
			for(Entry<String, String> map: h.entrySet()) {					
				d = d.replaceAll(map.getKey(), map.getValue().length() > 0 ? map.getValue() : "");
			}				
			sb.append(d);				
		}
		sb.append("</documents>");				
		this.saveToFile(sb, output);
	}

	/**
	 * Gets the content.
	 *
	 * @return the content
	 */
	public String getContent() {
		return content;
	}

	/**
	 * Gets the output.
	 *
	 * @return the output
	 */
	public String getOutput() {
		return output;
	}

	/**
	 * Gets the xml paterns.
	 *
	 * @return the xmlPaterns
	 */
	public XmlPatterns getXmlPaterns() {
		return xmlPaterns;
	}
	
	
	/**
	 * Save to file.
	 *
	 * @param sb the sb
	 * @param filename the filename
	 */
	public void saveToFile(StringBuffer sb,String filename) {
		BufferedWriter out = null;
		try {
			out = new BufferedWriter(new FileWriter(filename));
		} catch (IOException e) {
			logger.info("Error:", e);
			System.exit(1);
		}
		String outText = sb.toString();
		try {
			out.write(outText);
		} catch (IOException e) {
			logger.info("Error:", e);
			System.exit(1);
		}
		try {
			out.close();
		} catch (IOException e) {
			logger.info("Error:", e);
			System.exit(1);
		}
	}
	
	
	/**
	 * Gets the from.
	 *
	 * @param fileContent the file content
	 * @return the from
	 * @throws DocumentException the document exception
	 */
	public void getFrom(File fileContent ) throws DocumentException {
		this.doc.clearContent();
		this.loadFile(fileContent);
		
		Element  root = this.doc.getRootElement();
		Iterator elementIterator = root.elementIterator();
		while(elementIterator.hasNext()){
			Element element = (Element)elementIterator.next();
				Iterator inelementIterator = element.elementIterator();
				HashMap<String, String> hm = new HashMap<String,String>();
					while(inelementIterator.hasNext()) {
						Element inelement = (Element)inelementIterator.next();
						String val = inelement.getStringValue();
						
						hm.put(this.getkey(inelement.getName()),val);
					}
					this.fromList.add(hm);								
		}
	}
	
	
	/**
	 * Gets the key.
	 *
	 * @param name the name
	 * @return the key
	 */
	public String getkey(String name) {
		return this.patternList.get(name);
	}
		
	/**
	 * Gets the from list.
	 *
	 * @return the from list
	 */
	public List<HashMap<String,String>> getFromList() {
		return this.fromList;
	}
}
