/*
 * 
 */
package org.convertor.main;

import java.io.File;
import java.util.HashMap;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;

// TODO: Auto-generated Javadoc
/**
 * The Class LoadXml.
 */
abstract public class LoadXml {
	
	  /** The pattern list. */
  	protected HashMap<String, String> patternList;
	  
	  	  	  
	  
	  /**
  	 * Instantiates a new load xml.
  	 */
  	public LoadXml() {
		  this.patternList = new HashMap<String, String>();
	  }
	  
	  /** The doc. */
  	protected Document doc;
	  
	  /**
  	 * Load file.
  	 *
  	 * @param aFile the a file
  	 * @throws DocumentException the document exception
  	 */
  	public void loadFile(File aFile) throws DocumentException {
	    SAXReader xmlReader = new SAXReader();
	    this.doc = xmlReader.read(aFile);
	  }

	  

}
