package org.convertor.tests;
import static org.junit.Assert.*;

import java.util.HashMap;

import org.convertor.config.Configuration;
import org.convertor.main.Convertor;
import org.convertor.patterns.XmlPatterns;
import org.junit.Test;


// TODO: Auto-generated Javadoc
/**
 * The Class PrepareSourceTest.
 */
public class PrepareSourceTest {

	
	/**
	 * Test configuration path.
	 */
	@Test
	public void testConfigurationPath() {
		Configuration configuration = new Configuration();
		configuration.setPath("file://path");
		assertEquals("file://path",configuration.getPath());
	}
	
	
	/**
	 * Test configuration get source pattern path.
	 */
	@Test
	public void testConfigurationGetSourcePatternPath() {
		Configuration configuration = new Configuration();
			configuration.setPath("c:\\xml\\");
		assertEquals("c:\\xml\\patterns\\from.xml",configuration.getPattern("pattern.source"));
		assertTrue(configuration.getPattern("parn.source").length() == 0);
		assertTrue(configuration.getPattern("").length() == 0);
	}
	
	/**
	 * Test configuration get destination pattern path.
	 */
	@Test
	public void testConfigurationGetDestinationPatternPath() {
		Configuration configuration = new Configuration();
			configuration.setPath("c:\\xml\\");
		assertEquals("c:\\xml\\patterns\\to.xml",configuration.getPattern("pattern.destination"));
		assertTrue(configuration.getPattern("parn.source").length() == 0);
		assertTrue(configuration.getPattern("").length() == 0);
	}
	
	
	/**
	 * Test xml pattern get source key and value.
	 */
	@Test
	public void testXmlPatternGetSourceKeyAndValue() {
		Configuration configuration = new Configuration();
		configuration.setPath("c:\\xml\\");
		XmlPatterns xmlPatterns = new XmlPatterns(configuration);
		HashMap<String, String> pattern = xmlPatterns.getPattern("source"); 
		assertTrue(pattern.size() > 0);
		assertEquals("#ID#",pattern.get("id"));
		assertTrue(pattern.containsKey("id"));
	}
	
	/**
	 * Test xml pattern get destination key and value.
	 */
	@Test
	public void testXmlPatternGetDestinationKeyAndValue() {
		Configuration configuration = new Configuration();
		configuration.setPath("c:\\xml\\");
		XmlPatterns xmlPatterns = new XmlPatterns(configuration);
		HashMap<String, String> pattern = xmlPatterns.getPattern("destination"); 
		assertTrue(pattern.size() > 0);
		assertTrue(pattern.containsKey("destinationPattern"));
	}
	
	/**
	 * Test load file content to convert.
	 */
	@Test
	public void testLoadFileContentToConvert() {
		String content = "c:\\ElarYellowPages\\backup.xml";
		String output = "c:\\xml\\output\\output.xml";
		Configuration configuration = new Configuration();
		configuration.setPath("c:\\xml\\");
		XmlPatterns xmlPatterns = new XmlPatterns(configuration);
		Convertor convertor = new Convertor();
		convertor.setPatterns(xmlPatterns);
		convertor.setXmlFromFile(content);
		convertor.setXmlToFile(output);
		assertTrue(convertor.getContent().length() > 0);
		assertTrue(convertor.getOutput().length() > 0);
	}
	
	
	
	
	
	

}
