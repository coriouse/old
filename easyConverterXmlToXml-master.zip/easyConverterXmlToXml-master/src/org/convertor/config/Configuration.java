/*
 * 
 */
package org.convertor.config;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

// TODO: Auto-generated Javadoc
/**
 * The Class Configuration.
 */
public class Configuration {
	
	/** The properties. */
	private  Properties properties;
    
    /** The logger. */
    Logger logger = Logger.getLogger(this.getClass().getName());
	
	/** The path. */
	private String path;

	/**
	 * Gets the path.
	 *
	 * @return the path
	 */
	public String getPath() {
		return path;
	}

	/**
	 * Sets the path.
	 *
	 * @param path the path to set
	 */
	public void setPath(String path) {
		this.path = path;
		properties = new Properties();		
		try {
			properties.load(new FileInputStream(this.path+"etc\\config.property"));
			logger.info("Load config.property..."+this.path+"etc\\config.property");
		} catch (IOException e) {
			System.err.println("java -jar -c <path> -s <file> -d <file>");
			System.exit(1);
		} 
		
	}
	
	/**
	 * Gets the pattern.
	 *
	 * @param pattern the pattern
	 * @return the pattern
	 */
	public String getPattern(String pattern) {
		if(pattern.length() == 0 || pattern.indexOf("pattern") == -1) {
			return "";
		} 
		return this.properties.getProperty(pattern);
	}
	
	
	
	
	
}
